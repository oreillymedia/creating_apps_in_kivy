from kivy.app import App


class WeatherApp(App):
    pass

if __name__ == '__main__':
	WeatherApp().run()
