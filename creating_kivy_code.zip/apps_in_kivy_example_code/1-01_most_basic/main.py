from kivy.app import App


App().run()
